<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SmartParking</title>
<style>
  :root{
    --teal:#16c9a6;
    --navy:#12263f;
    --pad:56px;
    --dur:.6s;
    --ease:cubic-bezier(.65,0,.35,1);
  }
  *{box-sizing:border-box;margin:0}
  body{font-family:"Segoe UI",system-ui,sans-serif;background:#eefafa;color:var(--navy)}

  .nav{
    position:relative;
    height:80px;
    background:#fff;
    box-shadow:0 1px 0 rgba(0,0,0,.06);
    overflow:hidden;
  }

  /* LOGO */
  .logo{
    position:absolute;
    top:50%;
    left:var(--pad);
    display:flex;
    align-items:center;
    gap:10px;
    text-decoration:none;
    color:var(--navy);
    font-size:32px;
    letter-spacing:-.5px;
    white-space:nowrap;
    transform:translate(0,-50%);
    transition:transform var(--dur) var(--ease);
  }
  .logo .badge{
    width:44px;height:44px;border-radius:50%;
    background:var(--teal);color:#fff;
    display:grid;place-items:center;
    font-weight:700;font-size:24px;letter-spacing:0;
  }
  .logo span b{font-weight:800}
  .nav.collapsed .logo{
    transform:translate(var(--shift,0px),-50%);
  }

  /* LADO DIREITO */
  .right{
    position:absolute;
    top:0;right:var(--pad);
    height:100%;
    display:flex;
    align-items:center;
    gap:36px;
  }
  .links{
    display:flex;
    gap:36px;
    list-style:none;
    padding:0;
    transition:opacity .35s ease, transform var(--dur) var(--ease);
  }
  .links a{
    position:relative;
    display:block;
    padding:6px 0;
    font-size:16px;
    font-weight:500;
    color:var(--navy);
    text-decoration:none;
    cursor:pointer;
  }
  .links a::after{
    content:"";
    position:absolute;left:0;bottom:-6px;
    width:100%;height:3px;border-radius:2px;
    background:var(--teal);
    transform:scaleX(0);transform-origin:left;
    transition:transform .3s ease;
  }
  .links a:hover::after,
  .links a.active::after{transform:scaleX(1)}
  .links a.active{font-weight:700}

  /* some as informações */
  .nav.collapsed .links{
    opacity:0;
    transform:translateX(40px);
    pointer-events:none;
  }

  /* HAMBURGUER */
  .burger{
    width:28px;height:22px;
    background:none;border:0;padding:0;cursor:pointer;
    position:relative;
  }
  .burger i{
    position:absolute;left:0;width:100%;height:2.5px;border-radius:2px;
    background:var(--navy);
    transition:transform .4s var(--ease), opacity .2s ease, top .4s var(--ease);
  }
  .burger i:nth-child(1){top:2px}
  .burger i:nth-child(2){top:10px}
  .burger i:nth-child(3){top:18px}
  /* barra aberta = X | barra recolhida = três linhas */
  .nav:not(.collapsed) .burger i:nth-child(1){top:10px;transform:rotate(45deg)}
  .nav:not(.collapsed) .burger i:nth-child(2){opacity:0}
  .nav:not(.collapsed) .burger i:nth-child(3){top:10px;transform:rotate(-45deg)}

  @media (max-width:720px){
    :root{--pad:20px}
    .logo{font-size:24px}
    .logo .badge{width:36px;height:36px;font-size:19px}
    .links{gap:18px}
    .links a{font-size:14px}
    .right{gap:18px}
  }
</style>
</head>
<body>

<header class="nav" id="nav">
  <a class="logo" id="logo" href="#">
    <div class="badge">P</div>
    <span>Smart<b>Parking</b></span>
  </a>

  <div class="right">
    <ul class="links" id="links">
      <li><a class="active" href="index.php">Home</a></li>
      <li><a href="#vagas eletricas">Vagas Elétricas</a></li>
      <li><a href="#sobre nos">Sobre Nós</a></li>
      <li><a href="adm.php">Adm</a></li>
      <li><a href="login.php">Entrar/Cadastro</a></li>
      



    </ul>
    <button class="burger" id="burger" aria-label="Menu" aria-expanded="true">
      <i></i><i></i><i></i>
    </button>
  </div>
</header>

<script>
  const nav    = document.getElementById('nav');
  const logo   = document.getElementById('logo');
  const links  = document.querySelectorAll('#links a');
  const burger = document.getElementById('burger');

  // calcula quanto a logo precisa andar para ficar no centro
  function updateShift(){
    const pad   = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--pad'));
    const shift = (nav.clientWidth - logo.offsetWidth) / 2 - pad;
    nav.style.setProperty('--shift', shift + 'px');
  }
  updateShift();
  window.addEventListener('resize', updateShift);

  function setCollapsed(state){
    nav.classList.toggle('collapsed', state);
    burger.setAttribute('aria-expanded', String(!state));
  }

  // hambúrguer: alterna (recolhe / volta ao normal)
  burger.addEventListener('click', () => {
    setCollapsed(!nav.classList.contains('collapsed'));
  });
</script>
</body>
</html>