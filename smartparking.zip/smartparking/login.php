<?php
session_start();

$mensagem_erro = '';

// Verifica se o formulário foi enviado via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');

    // Validação simples
    if (empty($email) || empty($senha)) {
        $mensagem_erro = "Por favor, preencha todos os campos.";
    } else {
        // Substituir depois pela consulta ao banco de dados
        $email_valido = "guilhermemaran@outlook.com";
        $senha_valida = "123456";
        if ($email === $email_valido && $senha === $senha_valida) {
            $_SESSION['usuario'] = $email;
            exit;
        } else {
            $mensagem_erro = "E-mail ou senha incorretos!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./css/login.css">
</head>
<body>
    <?php require_once 'nav.php'; ?>

    <main class="login-container">
        <div class="card">
            <span>
                <img src="./img/icon.png" alt="Logo">      
                <h1 class="titulolog">Login</h1>
            </span>
            
            <!-- Exibe a mensagem de erro acima do formulário, se houver -->
            <?php if (!empty($mensagem_erro)): ?>
                <p style="color: red; text-align: center; margin-bottom: 15px;">
                    <?php echo $mensagem_erro; ?>
                </p>
            <?php endif; ?>

            <form action="" method="post" class="formulario">
                <label for="email">Seu e-mail:</label>
                <input name="email" id="email" type="email" placeholder="seu@email.com" required>

                <label for="senha">Sua senha:</label>
                <input type="password" id="senha" name="senha" placeholder="••••••••" required>

                <button type="submit" class="submit">Enviar</button>
                
                <div class="cadastro-link">
                    Não possui cadastro? <a href="cadastro.php">Cadastre-se</a>
                </div>
            </form>
        </div>
    </main>
</body>
</html>