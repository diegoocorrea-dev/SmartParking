<?php
 require_once 'nav.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartParking|adm</title>
    <link rel="stylesheet" href="./css/adm.css">
    <?php //area para criar variaveis
 $total_vagas = [
 ['A01','livre','comum'],['A02','ocupada','comum'],['A03','livre','comum'],['A04','livre','comum'],['A05','ocupada','comum'],['A06','livre','eletrica'],
 ['B01','livre','comum'],['B02','ocupada','comum'],['B03','livre','eletrica'],['B04','livre','comum'],['B05','ocupada','comum'],['B06','livre','eletrica']
];
    ?>
</head>
<body>
    <div class="dashboard">

        <aside class="sidebar">
        <!-- Seu menu lateral -->

        <img src="img/rodapé_adm.png" alt="rodapé" width ="315px">
    </aside>

     
        <div class ="coteudo">
    <h1 div class="txt"> Olá ADM!<h1>
        <h2 div class="sub_txt">Confira o resumo do seu estacionamento hoje. <h2>
            <?php
            date_default_timezone_set('America/Sao_Paulo');

            $data = date('d/m/Y');
            $horario = date ('H:i:s');

         
            ?>
    
    <div class="slots">
        <span class="slot1">
            <span class="slot1">
                <p>Total vagas
    <?php
    $vagas_livres = count(array_filter($total_vagas, fn($vaga) => $vaga[1] === 'livre'));
    echo $vagas_livres;
    ?>
    <div class="data-horario">
        <p>Data: <?php print $data;?> | Horário: <?php print $horario; ?>  </p>
        
    </div>


</span>
        </span>
        <span class="slot2"></span>
        <span class="slot3"></span>
        <span class="slot4"></span>


    </div>
    <div class="containers">
        <div class="container1">
    <div class="map">
        <h1> Mapa de Vagas <h1>
            <div class="dropdown">
    <button class="dropdown-btn" onclick="abrirMenu()">
        Todas os Setores ▼
    </button>

    <div class="dropdown-opcoes" id="menu">
        <a href="#">Térreo</a>
        <a href="#">Piso 1</a>
        <a href="#">Piso 2</a>
        <a href="#">Piso 3</a>   
    </div>
</div>
            
        <div class="panel"><div class="legend"><span><i class="dot"></i>Livre</span>
<span><i class="dot busy"></i>Ocupada</span>
<span><i class="dot ev"></i>Elétrica</span>
</div>

    <<img src="img/estacionamento.png" alt="Estacionamento">

</div>
</div>
  <script src="js/adm.js"></script>  
</body>
</html>