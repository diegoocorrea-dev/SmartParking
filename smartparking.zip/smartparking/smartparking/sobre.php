<?php $titulo = 'Sobre Nós'; $cena = 'sobre'; include 'inc/topo.php'; ?>

<section class="card">
  <h1>Sobre a SmartParking</h1>
  <p>Nascemos para tornar simples a vida de quem dirige carro elétrico ou híbrido: encontrar vaga com carregador, reservar e pagar em poucos toques.</p>
  <p>Nossa missão é ajudar a cidade a rodar com menos emissões, com estacionamentos preparados para o futuro.</p>
</section>

<section class="grid wide">
  <div class="card"><div class="num">24h</div><p>Atendimento e monitoramento</p></div>
  <div class="card"><div class="num">150 kW</div><p>Carregadores ultrarrápidos</p></div>
  <div class="card"><div class="num">100%</div><p>Vagas reservadas pelo app</p></div>
</section>

<?php include 'inc/rodape.php'; ?>
