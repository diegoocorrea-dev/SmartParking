<?php
// Cenas animadas (sem vídeo) para as páginas que não usam o vídeo.
// A página define $cena = 'home' | 'cadastro' | 'login' | 'contato' | 'vagas' | 'sobre'
$cena = $cena ?? 'home';
$alturas = [90, 140, 110, 170, 80, 150, 120, 180, 100, 130, 95, 160];
?>
<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="suv" viewBox="0 0 200 80">
    <path d="M8 58V46q0-8 9-10l30-8q10-16 28-18h46q20 2 32 16l24 8q9 3 9 12V58Z" fill="#e8eef3"/>
    <path d="M56 30q6-10 18-11h28v14H56ZM110 19h14q10 2 18 14h-32Z" fill="#7fb7d1"/>
    <circle cx="50" cy="58" r="14" fill="#1b2a38"/><circle cx="50" cy="58" r="6" fill="#aab8c4"/>
    <circle cx="152" cy="58" r="14" fill="#1b2a38"/><circle cx="152" cy="58" r="6" fill="#aab8c4"/>
  </symbol>
</svg>

<div class="cena cena-<?= $cena ?>" aria-hidden="true">

<?php if (in_array($cena, ['home', 'cadastro', 'login', 'contato'], true)): ?>
  <div class="nuvem n1"></div><div class="nuvem n2"></div>
  <svg class="predios" viewBox="0 0 1200 200" preserveAspectRatio="none">
    <?php foreach ($alturas as $i => $h): ?>
      <rect x="<?= $i * 100 ?>" y="<?= 200 - $h ?>" width="90" height="<?= $h ?>" fill="#a9c4d6" opacity=".85"/>
    <?php endforeach; ?>
  </svg>
  <div class="rua"></div>
  <div class="carregador"><i></i></div>
  <svg class="carro <?= $cena === 'cadastro' ? 'chega' : 'passa' ?>" viewBox="0 0 200 80"><use href="#suv"/></svg>

<?php elseif ($cena === 'vagas'): ?>
  <svg class="lote" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice">
    <?php for ($i = 0; $i < 9; $i++): $x = 80 + $i * 125; ?>
      <rect x="<?= $x ?>" y="90"  width="100" height="200" rx="6" fill="none" stroke="#fff" stroke-opacity=".28" stroke-width="2"/>
      <rect x="<?= $x ?>" y="410" width="100" height="200" rx="6" fill="none" stroke="#fff" stroke-opacity=".28" stroke-width="2"/>
      <?php if ($i % 2 === 0): ?><path class="raio" style="animation-delay:<?= $i * .3 ?>s" transform="translate(<?= $x + 28 ?> 160) scale(2)" d="M13 2 4 14h7l-1 8 9-12h-7z" fill="#17d9b5"/><?php endif; ?>
      <?php if ($i % 3 === 0): ?><path class="raio" style="animation-delay:<?= $i * .2 + .5 ?>s" transform="translate(<?= $x + 28 ?> 480) scale(2)" d="M13 2 4 14h7l-1 8 9-12h-7z" fill="#17d9b5"/><?php endif; ?>
    <?php endfor; ?>
    <g class="rodando"><rect x="-120" y="326" width="96" height="48" rx="12" fill="#e8eef3"/><rect x="-96" y="334" width="40" height="18" rx="4" fill="#7fb7d1"/></g>
    <g class="rodando volta"><rect x="1300" y="372" width="96" height="48" rx="12" fill="#17d9b5"/><rect x="1316" y="380" width="40" height="18" rx="4" fill="#0e2237" opacity=".5"/></g>
  </svg>

<?php else: /* sobre */ ?>
  <?php for ($i = 0; $i < 16; $i++): ?>
    <span class="bolha" style="--x:<?= ($i * 37) % 100 ?>%;--s:<?= 10 + ($i * 7) % 28 ?>px;--d:<?= 9 + ($i * 3) % 9 ?>s;--a:-<?= $i * 1.3 ?>s"></span>
  <?php endfor; ?>
  <svg class="anel" viewBox="0 0 200 200">
    <circle cx="100" cy="100" r="92" fill="none" stroke="#17d9b5" stroke-width="3" stroke-dasharray="14 10"/>
  </svg>
  <svg class="anel-p" viewBox="0 0 200 200"><path d="M72 150V50h40a30 30 0 0 1 0 60H72" fill="none" stroke="#17d9b5" stroke-width="16" stroke-linecap="round" stroke-linejoin="round"/></svg>
<?php endif; ?>

</div>
