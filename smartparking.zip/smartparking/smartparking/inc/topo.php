<?php
// Transição vinda da página anterior (o JS grava um cookie ao clicar num link)
$t = $_COOKIE['trans'] ?? '';
$t = in_array($t, ['cortina', 'circulo', 'suave'], true) ? $t : '';
if ($t) setcookie('trans', '', time() - 3600, '/');   // usa uma vez só

// Cabeçalho comum a todas as páginas. Antes de incluir, a página define $titulo.
$menu  = ['index.php' => 'Home', 'vagas.php' => 'Vagas Elétricas', 'sobre.php' => 'Sobre Nós', 'contato.php' => 'Contato', 'login.php' => 'Entrar'];
$atual = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($titulo ?? 'Início') ?> – SmartParking</title>
<link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
<?php include __DIR__ . '/cena.php'; ?>

<!-- Camada das transições entre páginas. Se veio de um clique, já nasce cobrindo a tela e "revela" a página -->
<div class="trans<?= $t ? " $t revela" : '' ?>" id="trans" aria-hidden="true">
  <svg viewBox="0 0 34 34"><circle cx="17" cy="17" r="17" fill="#fff"/><path d="M12 25V9h6.5a5 5 0 0 1 0 10H12" fill="none" stroke="#17d9b5" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>

<header>
  <a class="logo" href="index.php">
    <svg width="34" height="34" viewBox="0 0 34 34" aria-hidden="true"><circle cx="17" cy="17" r="17" fill="#17d9b5"/><path d="M12 25V9h6.5a5 5 0 0 1 0 10H12" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
    <span>Smart</span><b>Parking</b>
  </a>
  <nav>
    <?php foreach ($menu as $arquivo => $nome): ?>
      <a href="<?= $arquivo ?>"<?= $arquivo === $atual ? ' class="ativo"' : '' ?>><?= $nome ?></a>
    <?php endforeach; ?>
  </nav>
</header>
<main>
