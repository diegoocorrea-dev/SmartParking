// Transições entre páginas (sem vídeo).
//  clicar em "Entrar"   -> cortina que varre a tela da direita para a esquerda
//  clicar em "Cadastro" -> círculo que cresce a partir do ponto clicado
//  outros links         -> fade suave
// Funcionamento: ao clicar, a camada #trans cobre a tela; só depois a próxima página abre.
// O tipo fica num cookie; o PHP (inc/topo.php) lê o cookie e já abre a nova página
// coberta, "revelando" o conteúdo com a animação contrária.
(() => {
  const ov = document.getElementById('trans');
  const reduzir = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let saindo = false;

  // fim da animação de entrada: deixa a camada escondida
  ov.addEventListener('animationend', () => { if (ov.classList.contains('revela')) ov.className = 'trans'; });

  function tipoDe(url) {
    const arq = url.pathname.split('/').pop();
    if (arq === 'login.php')    return 'cortina';
    if (arq === 'cadastro.php') return 'circulo';
    return 'suave';
  }

  document.addEventListener('click', e => {
    const a = e.target.closest('a[href]');
    if (!a || reduzir || saindo) return;
    if (a.target === '_blank' || a.origin !== location.origin || a.getAttribute('href').startsWith('#')) return;
    if (e.metaKey || e.ctrlKey || e.shiftKey) return;           // abrir em nova aba continua normal
    e.preventDefault();
    saindo = true;

    const tipo = tipoDe(new URL(a.href));
    document.cookie = 'trans=' + tipo + '; path=/; max-age=15; SameSite=Lax';
    ov.style.setProperty('--x', e.clientX + 'px');
    ov.style.setProperty('--y', e.clientY + 'px');
    document.body.classList.add('saindo');
    ov.className = 'trans ' + tipo + ' cobre';

    let foi = false;
    const ir = () => { if (!foi) { foi = true; location.href = a.href; } };
    ov.addEventListener('animationend', ir, { once: true });
    setTimeout(ir, 1200);                                        // segurança
  });

  // botão "voltar" do navegador: desfaz o estado de saída
  addEventListener('pageshow', e => {
    if (e.persisted) { saindo = false; ov.className = 'trans'; document.body.classList.remove('saindo'); }
  });
})();
