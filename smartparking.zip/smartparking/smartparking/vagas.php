<?php
$titulo = 'Vagas Elétricas'; $cena = 'vagas';
// Lista de exemplo: código, tipo, conector, livre?  (depois isso virá do banco de dados)
$vagas = [
  ['A1', 'Elétrico', 'CCS2 · 50 kW',   true],
  ['A2', 'Elétrico', 'CCS2 · 50 kW',   false],
  ['A3', 'Elétrico', 'Tipo 2 · 22 kW', true],
  ['B1', 'Elétrico', 'Tipo 2 · 22 kW', true],
  ['B2', 'Híbrido',  'Tipo 2 · 7 kW',  false],
  ['B3', 'Híbrido',  'Tipo 2 · 7 kW',  true],
  ['C1', 'Híbrido',  'Tipo 2 · 7 kW',  true],
  ['C2', 'Elétrico', 'CCS2 · 150 kW',  true],
];
include 'inc/topo.php';
?>
<section class="card">
  <h1>Vagas com carregador</h1>
  <p>Veja o que está livre agora e reserve criando sua conta.</p>
</section>

<section class="grid wide">
  <?php foreach ($vagas as [$cod, $tipo, $conector, $livre]): ?>
    <div class="card vaga">
      <h3>Vaga <?= $cod ?> <span class="tag <?= $livre ? 'livre' : 'ocupada' ?>"><?= $livre ? 'Livre' : 'Ocupada' ?></span></h3>
      <small><?= $tipo ?> · <?= $conector ?></small>
      <?php if ($livre): ?><a class="btn" href="cadastro.php">Reservar</a><?php endif; ?>
    </div>
  <?php endforeach; ?>
</section>

<?php include 'inc/rodape.php'; ?>
