<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro</title>
  <!-- Lembre-se de verificar se o link abaixo aponta corretamente para o seu arquivo CSS -->
    <link rel="stylesheet" href="./css/cadastro.css">
</head>
<body>
  <?php require_once 'nav.php'?>
  <!-- CARD CENTRALIZADO -->
  <div class="card">
    
    <!-- CABEÇALHO -->
    <div class="header-cadastro">
      <div class="icon-main">
        <!-- Ícone de Usuário principal (SVG limpo para não quebrar) -->
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
      </div>
      <h2 class="titulolog">Cadastro</h2>
    </div>

    <!-- FORMULÁRIO -->
    <form class="formulario">
      
      <!-- Campo: Nome -->
      <div class="input-group">
        <span class="input-icon">👤</span>
        <label for="nome">Nome:</label>
        <input type="text" id="nome">
      </div>

      <!-- Campo: Email -->
      <div class="input-group">
        <span class="input-icon">✉️</span>
        <label for="email">Email:</label>
        <input type="email" id="email">
      </div>

      <!-- Campo: CPF -->
      <div class="input-group">
        <span class="input-icon">📄</span>
        <label for="cpf">CPF:</label>
        <input type="text" id="cpf">
      </div>

      <!-- LINHA: Senha e Telefone lado a lado -->
      <div class="form-row">
        <div class="input-group">
          <span class="input-icon">🔒</span>
          <label for="senha">Senha:</label>
          <input type="password" id="senha">
        </div>
        
        <div class="input-group">
          <span class="input-icon">📞</span>
          <label for="telefone">Telefone:</label>
          <input type="tel" id="telefone">
        </div>
      </div>

      <!-- SUBSEÇÃO: Veículo -->
      <div class="subsecao-titulo">
        <span class="car-icon">🚗</span>
        <h3>Veículo</h3>
      </div>

      <!-- Campo: Modelo -->
    <div class="input-group">
  <span class="input-icon">🚘</span>
  <label for="modelo">Modelo:</label>
  <select id="modelo" name="modelo">
    <option value="" disabled selected>Selecione um modelo</option>
    <option value="Combustão">Combustão</option>
    <option value="Elétrico">Elétrico</option>
    <option value="Híbrido">Híbrido</option>
  </select>
</div>

      <!-- Campo: Nome do Carro -->
      <div class="input-group">
        <span class="input-icon">🏷️</span>
        <label for="nome-carro">nome do carro:</label>
        <input type="text" id="nome-carro">
      </div>

      <!-- Campo: Placa -->
      <div class="input-group">
        <span class="input-icon">📍</span>
        <label for="placa">Placa:</label>
        <input type="text" id="placa">
      </div>

      <!-- Link de login -->
      <div class="login-link">
        Já possui cadastro? <a href="login.php">Logue-se</a>
      </div>

      <!-- Botão Cadastrar -->
      <button type="submit" class="submit">
        <!-- Ícone de aviãozinho SVG para o botão -->
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
        Cadastrar
      </button>

    </form> <!-- Fecha Form -->
  </div> <!-- Fecha Card -->  

  <script src="js/adm.js"></script>
</body>
</html>
