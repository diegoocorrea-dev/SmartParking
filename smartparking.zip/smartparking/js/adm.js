function abrirMenu() {
    let menu = document.getElementById("menu");

    menu.classList.toggle("ativo");
}